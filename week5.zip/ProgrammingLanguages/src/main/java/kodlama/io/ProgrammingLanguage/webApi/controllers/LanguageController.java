package kodlama.io.ProgrammingLanguage.webApi.controllers;

import kodlama.io.ProgrammingLanguage.business.Abstracts.LanguagesService;
import kodlama.io.ProgrammingLanguage.business.Request.CreateLanguageRequest;
import kodlama.io.ProgrammingLanguage.business.Request.UpdateLanguageRequest;
import kodlama.io.ProgrammingLanguage.business.Responses.GetAllLanguageResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/languages")
public class LanguageController {

    private LanguagesService languagesService;

    @Autowired
    public LanguageController(LanguagesService languagesService) {
        this.languagesService = languagesService;
    }

    @GetMapping("/getAll")
    public List<GetAllLanguageResponse> getAll(){

        return languagesService.getAll();
    }

    @PostMapping("/add")
    public void add(CreateLanguageRequest createLanguageRequest) throws Exception {
        this.languagesService.add(createLanguageRequest);

    }
    @PutMapping("/update")
    public void update(int id,UpdateLanguageRequest updateLanguageRequest) throws Exception {

        this.languagesService.update(id,updateLanguageRequest);
    }
    @DeleteMapping("/delete")
    public void delete(int id){

        this.languagesService.deleteById(id);
    }

}
