package kodlama.io.ProgrammingLanguage.webApi.controllers;

import kodlama.io.ProgrammingLanguage.business.Abstracts.LanguageTechnologiesService;
import kodlama.io.ProgrammingLanguage.business.Request.CreateLanguageRequest;
import kodlama.io.ProgrammingLanguage.business.Request.CreateTechnologiesRequest;
import kodlama.io.ProgrammingLanguage.business.Request.UpdateTechnologiesRequest;
import kodlama.io.ProgrammingLanguage.business.Responses.GetAllTechnologyResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/technology")
public class TechnologyController {

    private LanguageTechnologiesService languageTechnologiesService;
    @Autowired
    public TechnologyController(LanguageTechnologiesService languageTechnologiesService) {
        this.languageTechnologiesService = languageTechnologiesService;
    }

    @GetMapping("/getAll")
    public List<GetAllTechnologyResponse> getAll(){
        return languageTechnologiesService.getAll();
    }
    @PostMapping("/add")
    public void add( CreateTechnologiesRequest createTechnologiesRequest) throws Exception {


        this.languageTechnologiesService.add(createTechnologiesRequest);
    }
    @DeleteMapping("/delete")
    public void delete(int id){

        this.languageTechnologiesService.delete(id);
    }
    @PutMapping("/Update")
    public void update(int id , UpdateTechnologiesRequest updateTechnologiesRequest){

        this.languageTechnologiesService.update(id,updateTechnologiesRequest);

    }
}
