package kodlama.io.ProgrammingLanguage.dataAccess.Abstracts;

import kodlama.io.ProgrammingLanguage.entities.Concrates.LanguageTechnologies;
import org.springframework.data.jpa.repository.JpaRepository;



public interface LanguageTechnologiesRepository extends JpaRepository<LanguageTechnologies,Integer> {
}
