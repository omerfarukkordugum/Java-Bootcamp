package kodlama.io.ProgrammingLanguage.business.Concretes;

import kodlama.io.ProgrammingLanguage.business.Abstracts.LanguagesService;
import kodlama.io.ProgrammingLanguage.business.Request.CreateLanguageRequest;
import kodlama.io.ProgrammingLanguage.business.Request.UpdateLanguageRequest;
import kodlama.io.ProgrammingLanguage.business.Responses.GetAllLanguageResponse;
import kodlama.io.ProgrammingLanguage.dataAccess.Abstracts.LanguagesRepository;
import kodlama.io.ProgrammingLanguage.entities.Concrates.Languages;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class LanguagesManager implements LanguagesService {

    private LanguagesRepository languagesRepository;


    @Autowired
    public LanguagesManager(LanguagesRepository languagesRepository) {
        this.languagesRepository = languagesRepository;
    }


    @Override
    public List<GetAllLanguageResponse> getAll() {
        List<Languages> languages = languagesRepository.findAll();
        List<GetAllLanguageResponse> getAllLanguageResponses = new ArrayList<GetAllLanguageResponse>();
        for (Languages language : languages) {
            GetAllLanguageResponse languageResponseItem = new GetAllLanguageResponse();
            languageResponseItem.setLanguage_id(language.getId());
            languageResponseItem.setLanguageName(language.getLanguageName());
            getAllLanguageResponses.add(languageResponseItem);

        }


        return getAllLanguageResponses;
    }

    @Override
    public void add(CreateLanguageRequest createLanguageRequest) throws Exception {
        for (GetAllLanguageResponse languages:getAll()){
            if (createLanguageRequest.getLanguage_name().equals(languages.getLanguageName()))
                throw new Exception("sistemde böyle bir dil mevcut");
        }
        if (createLanguageRequest.getLanguage_name().isEmpty()){
            throw new Exception("İsim alanı boş olamaz");
        }

        Languages languages = new Languages();
        languages.setLanguageName(createLanguageRequest.getLanguage_name());
        this.languagesRepository.save(languages);

    }

    @Override
    public void update(int id, UpdateLanguageRequest updateLanguageRequest) throws Exception {


        Languages languages = languagesRepository.findById(id).get();
        languages.setLanguageName(updateLanguageRequest.getLanguageName());


        this.languagesRepository.save(languages);

    }

    @Override
    public void deleteById(int id) {

        boolean isExist = languagesRepository.existsById(id);
        languagesRepository.deleteById(id);
    }


}
