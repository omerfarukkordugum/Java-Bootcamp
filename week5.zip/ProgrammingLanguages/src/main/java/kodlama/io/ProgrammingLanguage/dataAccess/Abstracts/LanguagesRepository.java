package kodlama.io.ProgrammingLanguage.dataAccess.Abstracts;

import kodlama.io.ProgrammingLanguage.entities.Concrates.Languages;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LanguagesRepository extends JpaRepository<Languages,Integer> {

}
