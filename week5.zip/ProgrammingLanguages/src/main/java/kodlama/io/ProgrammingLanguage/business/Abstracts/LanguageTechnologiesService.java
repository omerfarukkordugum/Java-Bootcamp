package kodlama.io.ProgrammingLanguage.business.Abstracts;

import kodlama.io.ProgrammingLanguage.business.Request.CreateTechnologiesRequest;
import kodlama.io.ProgrammingLanguage.business.Request.UpdateTechnologiesRequest;
import kodlama.io.ProgrammingLanguage.business.Responses.GetAllTechnologyResponse;

import java.util.List;

public interface LanguageTechnologiesService {
    List<GetAllTechnologyResponse> getAll();
    void add( CreateTechnologiesRequest createTechnologiesRequest) throws Exception;
    void delete(int id);
    void update (int id, UpdateTechnologiesRequest updateTechnologiesRequest);

}
