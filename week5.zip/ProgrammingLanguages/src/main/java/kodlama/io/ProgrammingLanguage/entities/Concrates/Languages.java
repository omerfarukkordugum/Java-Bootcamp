package kodlama.io.ProgrammingLanguage.entities.Concrates;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;
import java.util.List;

@Table(name = "Languages")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity

public class Languages {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Language_id")
    private int id;
    @Column(name = "LanguageName")
    private String LanguageName;

    @OneToMany(mappedBy = "languages", fetch = FetchType.LAZY ,cascade = CascadeType.ALL)
    private List<LanguageTechnologies> languageTechnologies;

}
