package kodlama.io.ProgrammingLanguage.business.Responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetAllTechnologyResponse {

    private String Language_name;
    private int Technology_id;
    private String TechnologyName;
}
