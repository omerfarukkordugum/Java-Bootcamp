package kodlama.io.ProgrammingLanguage.business.Abstracts;

import kodlama.io.ProgrammingLanguage.business.Request.CreateLanguageRequest;
import kodlama.io.ProgrammingLanguage.business.Request.UpdateLanguageRequest;
import kodlama.io.ProgrammingLanguage.business.Responses.GetAllLanguageResponse;


import java.util.List;

public interface LanguagesService {

    List<GetAllLanguageResponse> getAll();

    void add(CreateLanguageRequest createLanguageRequest) throws Exception;

    void update(int id, UpdateLanguageRequest updateLanguageRequest) throws Exception;

    void deleteById(int id);

}
