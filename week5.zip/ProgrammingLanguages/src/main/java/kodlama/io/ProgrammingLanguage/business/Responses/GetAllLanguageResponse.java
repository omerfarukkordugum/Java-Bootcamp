package kodlama.io.ProgrammingLanguage.business.Responses;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetAllLanguageResponse {

    private int Language_id;
    private String LanguageName ;

}
