package kodlama.io.ProgrammingLanguage.business.Concretes;

import kodlama.io.ProgrammingLanguage.business.Abstracts.LanguageTechnologiesService;
import kodlama.io.ProgrammingLanguage.business.Request.CreateTechnologiesRequest;
import kodlama.io.ProgrammingLanguage.business.Request.UpdateTechnologiesRequest;
import kodlama.io.ProgrammingLanguage.business.Responses.GetAllTechnologyResponse;
import kodlama.io.ProgrammingLanguage.dataAccess.Abstracts.LanguageTechnologiesRepository;
import kodlama.io.ProgrammingLanguage.dataAccess.Abstracts.LanguagesRepository;
import kodlama.io.ProgrammingLanguage.entities.Concrates.LanguageTechnologies;
import kodlama.io.ProgrammingLanguage.entities.Concrates.Languages;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class LanguageTechnologiesManager implements LanguageTechnologiesService {

    private LanguageTechnologiesRepository languageTechnologiesRepository;
    private LanguagesRepository languagesRepository;

    @Autowired
    public LanguageTechnologiesManager(LanguageTechnologiesRepository languageTechnologiesRepository, LanguagesRepository languagesRepository) {
        this.languageTechnologiesRepository = languageTechnologiesRepository;
        this.languagesRepository = languagesRepository;
    }


    @Override
    public List<GetAllTechnologyResponse> getAll() {
        List<LanguageTechnologies> languageTechnologies = languageTechnologiesRepository.findAll();
        List<GetAllTechnologyResponse> getAllTechnologyResponses = new ArrayList<GetAllTechnologyResponse>();

        for (LanguageTechnologies languageTechnologie : languageTechnologies) {

            GetAllTechnologyResponse TechnologyResponseItem = new GetAllTechnologyResponse();
            TechnologyResponseItem.setLanguage_name(languageTechnologie.getLanguages().getLanguageName());
            TechnologyResponseItem.setTechnology_id(languageTechnologie.getId());
            TechnologyResponseItem.setTechnologyName(languageTechnologie.getTechnologyName());


            getAllTechnologyResponses.add(TechnologyResponseItem);
        }

        return getAllTechnologyResponses;
    }

    @Override
    public void add(CreateTechnologiesRequest createTechnologiesRequest) throws Exception {
        for (GetAllTechnologyResponse TechnologyResponse:getAll()){

            if (createTechnologiesRequest.getTechnologyName().equals(TechnologyResponse.getTechnologyName()))
                throw new Exception("Bu Teknoloji zaten kayıtlı");

            if (createTechnologiesRequest.getTechnologyName().isEmpty())
                throw new Exception("Bir teknoloji ismi giremediniz");
        }
        LanguageTechnologies languageTechnologies=new LanguageTechnologies();
        Languages languages = languagesRepository.findById(createTechnologiesRequest.getLanguageId()).get();
        languageTechnologies.setTechnologyName(createTechnologiesRequest.getTechnologyName());
        languageTechnologies.setLanguages(languages);

        languageTechnologiesRepository.save(languageTechnologies);

    }

    @Override
    public void delete(int id) {

        languageTechnologiesRepository.deleteById(id);
    }

    @Override
    public void update(int id, UpdateTechnologiesRequest updateTechnologiesRequest) {
        LanguageTechnologies languageTechnologies = languageTechnologiesRepository.findById(id).get();
        Languages languages = languagesRepository.findById(updateTechnologiesRequest.getLanguageId()).get();
        languageTechnologies.setLanguages(languages);

        languageTechnologies.setTechnologyName(updateTechnologiesRequest.getTechnologyName());

        languageTechnologiesRepository.save(languageTechnologies);


    }

}
