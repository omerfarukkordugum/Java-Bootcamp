package kodlama.io.ProgrammingLanguage.entities.Concrates;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;

@Table(name = "LanguageTechnologies")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class LanguageTechnologies {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Technology_id")
    private int id;

    @Column(name = "TechnologyName")
    private String TechnologyName;
    @ManyToOne
    @JoinColumn(name = "Language_id")
    private Languages languages;
}
